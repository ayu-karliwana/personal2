document.getElementById("urutan").addEventListener("change", function () {
  const urutan = this.value;

  fetch("nama-bali.json")
    .then((res) => res.json())
    .then((data) => {
      const info = data[urutan];
      document.getElementById("laki").textContent = info["laki-laki"].join(", ");
      document.getElementById("perempuan").textContent = info["perempuan"].join(", ");
    });
});
